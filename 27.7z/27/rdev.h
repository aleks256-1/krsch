#ifndef RDEV_H
#define RDEV_H

int RangedRandomNumber(int min, int max);

#endif