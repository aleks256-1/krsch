#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <malloc.h>
#include <iostream>
#include <bitset>
#include <unistd.h>


#include "cross.h"
#include "mutations.h"
#include "creature.h"
#include "main.h"
#include "genome.h"
#include "embriogenesis.h"
#include "bmpgen.h"
#include <cmath>

using namespace std;

int IMAGE_WIDTH;
int IMAGE_HEIGHT;

unsigned char* readBMP(char* filename)
{
    int i;
    FILE* f = fopen(filename, "rb");
    unsigned char info[54];
    fread(info, sizeof(unsigned char), 54, f); // read the 54-byte header

    // extract image height and width from header
    IMAGE_WIDTH = *(int*)&info[18];
    IMAGE_HEIGHT = *(int*)&info[22];

    int size = 3 * IMAGE_WIDTH * IMAGE_HEIGHT;
    cout << IMAGE_WIDTH << ' ' << IMAGE_HEIGHT << '\n';
    unsigned char* data = new unsigned char[size]; // allocate 3 bytes per pixel
    fread(data, sizeof(unsigned char), size, f); // read the rest of the data at once
    fclose(f);

    for(i = 0; i < size; i += 3)
    {
            unsigned char tmp = data[i];
            data[i] = data[i+2];
            data[i+2] = tmp;
    }

    return data;
}


int main(int argc, char ** argv) {
    /* -------------- INITIALIZING VARIABLES -------------- */
    int client; // socket file descriptors
    int portNum = 8080; // port number (same that server)
    int bufsize = 65536; // buffer size
    char buffer[bufsize]; // buffer to transmit
    char ip[] = "127.0.0.1"; // Server IP
    bool isExit = false; // var fo continue infinitly
     /* Structure describing an Internet socket address. */
    struct sockaddr_in server_addr;
    cout << "\n- Starting client..." << endl;
     /* ---------- ESTABLISHING SOCKET CONNECTION ----------*/
    client = socket(AF_INET, SOCK_STREAM, 0);
    if (client < 0) {
        cout << "\n-Error establishing socket..." << endl;
        exit(-1);
    }
    cout << "\n- Socket client has been created..." << endl;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(portNum);
    inet_pton(AF_INET, ip, &server_addr.sin_addr);
 /* ---------- CONNECTING THE SOCKET ---------- */
    if (connect(client, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0)
        cout << "- Connection to the server port number: " << portNum << endl;
    cout << "- Awaiting confirmation from the server..." << endl; //line 40
 // recive the welcome message from server
    cout << "- Connection confirmed, you are good to go!" << endl;

    struct creature * creature;
    struct matrix * matrix;
    struct uint16_genome * nextGeneration = (struct uint16_genome *)malloc(sizeof(struct uint16_genome));
    struct genome * genome = (struct genome *)malloc(sizeof(struct genome));
    struct creature * MyCreature = (struct creature*)malloc(sizeof(struct creature));
    unsigned char * image = readBMP((char*)"ideal.bmp");
    ssize_t rec;
    int res, i, step;
    init_blur_matrix(&matrix);


    do {
            strcpy(buffer, to_string(1).c_str());  
            send(client , buffer , bufsize , 0 );
            rec = 0;
            do {
                res = recv(client, &buffer[rec], bufsize - rec, 0);
                rec += res;
            } while (rec < bufsize);
            int a = atoi(buffer);
        
        cout << a << '\n';


    } while (!isExit);



    if (nextGeneration) {
        free(nextGeneration->genes);
        free(nextGeneration);
    }
    if (genome) {
        free(genome->genes);
        free(genome);
    }
    if (creature) {
        free(creature->cells);
        free(creature);
    }
    free(MyCreature->cells);
    free(MyCreature);
    free(matrix);
    free(image);

 /* ---------------- CLOSE CALL ------------- */
    cout << "\nConnection terminated.\n";
    close(client);
    return 0;
}
