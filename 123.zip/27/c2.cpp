#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <malloc.h>
#include <iostream>
#include <bitset>
#include <unistd.h>


#include "cross.h"
#include "mutations.h"
#include "creature.h"
#include "main.h"
#include "genome.h"
#include "embriogenesis.h"
#include "bmpgen.h"
#include <cmath>

int IMAGE_WIDTH;
int IMAGE_HEIGHT;

unsigned char* readBMP(char* filename)
{
    int i;
    FILE* f = fopen(filename, "rb");
    unsigned char info[54];
    fread(info, sizeof(unsigned char), 54, f); // read the 54-byte header

    // extract image height and width from header
    IMAGE_WIDTH = *(int*)&info[18];
    IMAGE_HEIGHT = *(int*)&info[22];

    int size = 3 * IMAGE_WIDTH * IMAGE_HEIGHT;
    cout << IMAGE_WIDTH << ' ' << IMAGE_HEIGHT << '\n';
    unsigned char* data = new unsigned char[size]; // allocate 3 bytes per pixel
    fread(data, sizeof(unsigned char), size, f); // read the rest of the data at once
    fclose(f);

    for(i = 0; i < size; i += 3)
    {
            unsigned char tmp = data[i];
            data[i] = data[i+2];
            data[i+2] = tmp;
    }

    return data;
}

using namespace std;


int main(int argc, char ** argv) {
    /* -------------- INITIALIZING VARIABLES -------------- */
    int client; // socket file descriptors
    int portNum = 8080; // port number (same that server)
    int bufsize = 65536; // buffer size
    char buffer[bufsize]; // buffer to transmit
    char ip[] = "127.0.0.1"; // Server IP
    bool isExit = false; // var fo continue infinitly
     /* Structure describing an Internet socket address. */
    struct sockaddr_in server_addr;
    cout << "\n- Starting client..." << endl;
     /* ---------- ESTABLISHING SOCKET CONNECTION ----------*/
    client = socket(AF_INET, SOCK_STREAM, 0);
    if (client < 0) {
        cout << "\n-Error establishing socket..." << endl;
        exit(-1);
    }
    cout << "\n- Socket client has been created..." << endl;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(portNum);
    inet_pton(AF_INET, ip, &server_addr.sin_addr);
 /* ---------- CONNECTING THE SOCKET ---------- */
    if (connect(client, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0)
        cout << "- Connection to the server port number: " << portNum << endl;
    cout << "- Awaiting confirmation from the server..." << endl; //line 40
 // recive the welcome message from server
    cout << "- Connection confirmed, you are good to go!" << endl;
    ssize_t rec;
    int res, i, step;
    struct uint16_genome * nextGeneration;
    struct genome * genome;
    struct creature * creature = (struct creature *)malloc(sizeof(struct creature));
    struct matrix * matrix;
    nextGeneration = (struct uint16_genome *)malloc(sizeof(struct uint16_genome));
    genome = (struct genome *)malloc(sizeof(struct genome));
    init_blur_matrix(&matrix);
    struct creature * MyCreature;
    MyCreature = (struct creature*)malloc(sizeof(struct creature));
    initCreature(MyCreature);
    
    unsigned char * image;
    //    readBitmapImage((unsigned char *)image, 225, 225, (char *)("IdealImage.bmp"));
        image = readBMP((char*)"ideal.bmp");
        generateBitmapImage(image, IMAGE_HEIGHT, IMAGE_WIDTH, (char*)"generated.bmp");
    write(client, buffer, bufsize);
    do {
        rec = 0;
        do {
            int res = recv(client, &buffer[rec], bufsize-rec, 0);
            rec+=res;
        } while (rec<bufsize);
        cout << "1st = " << atoi(buffer) << '\n';
        if (atoi(buffer) == 123456789) {
            rec = 0;
            do {
                int res = send(client, &buffer[rec], bufsize-rec, 0);
                rec+=res;
            } while (rec<bufsize);
        } else {
            rec = 0;
            do {
                res = recv(client, &buffer[rec], bufsize - rec, 0);
                rec += res;
            } while (rec < bufsize);
            int genomeNumber = atoi(buffer);
            cout << "2nd = " << atoi(buffer) << '\n';


            rec = 0;
            do {
                res = send(client, &buffer[rec], bufsize - rec, 0);
                rec += res;
            } while (rec < bufsize);
            cout << "sent" << '\n';
            

















        }
    } while (!isExit);

    free(nextGeneration);
    free(genome);

 /* ---------------- CLOSE CALL ------------- */
    cout << "\nConnection terminated.\n";
    close(client);
    return 0;
}
