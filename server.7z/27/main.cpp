#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros 
#include <iostream>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <malloc.h>
#include <iostream>
#include <bitset>
#include <unistd.h>

#include "cross.h"
#include "mutations.h"
#include "creature.h"
#include "main.h"
#include "rdev.h"
#include "genome.h"
#include "embriogenesis.h"
#include "bmpgen.h"

using namespace std;   

int main() {

    struct uint16_genome ** firstGeneration, ** nextGeneration;
    firstGeneration = (struct uint16_genome **)malloc(START_POPULATION * sizeof(struct uint16_genome *));
    nextGeneration = (struct uint16_genome **)malloc(NEXT_GENERATION_POPULATION * sizeof(struct uint16_genome *));
    for (int i = 0; i < START_POPULATION; i++) {
        firstGeneration[i] = (struct uint16_genome *)malloc(sizeof(struct uint16_genome));
        initRandGenome_uint16(firstGeneration[i]);
    }                                                  
    for (int i = 0; i < NEXT_GENERATION_POPULATION; i++) {
        nextGeneration[i] = (struct uint16_genome *)malloc(sizeof(struct uint16_genome));
    }

    for (int i = 0; i < START_POPULATION; i++) {
            if (nextGeneration[i]->genes) {
                free(nextGeneration[i]->genes);
            }
            copyGenome_uint16(firstGeneration[i], nextGeneration[i]);
        }
        for (int i = START_POPULATION; i < NEXT_GENERATION_POPULATION; i++) {
            if (nextGeneration[i]->genes) {
                free(nextGeneration[i]->genes);
            }
            crossGenome_uint16(firstGeneration[RangedRandomNumber(0, START_POPULATION - 1)], 
                                firstGeneration[RangedRandomNumber(0, START_POPULATION - 1)],
                                nextGeneration[i]);
    }

    int numberOfMutations = RangedRandomNumber(NEXT_GENERATION_POPULATION/2, NEXT_GENERATION_POPULATION); 
        for (int i = 0; i < numberOfMutations; i++) {                                           
            int mutation = RangedRandomNumber(0,100);                                          
            int creature = RangedRandomNumber(0, NEXT_GENERATION_POPULATION - 1);                        
            if (mutation < 13) {
                cout << 1;                     
                ChangeRandomBits(nextGeneration[creature]);                           
            } else if (mutation < 25) {    
                cout << 2;
                RandomFragmentDeletion(nextGeneration[creature]);                          
//            } else if (mutation < 38) {                                                         
//                RandomFragmentInsetrion(nextGeneration[creature]);                         
//            } else if (mutation < 50) {    
//                RandomFragmentDuplicate(nextGeneration[creature]);                    
//            } else if (mutation < 63) {                                    
//                RandomFragmentMove(nextGeneration[creature]);                            
//            } else if (mutation < 75) {  
//                RandomFragmentCopy(nextGeneration[creature]);                            
//            } else if (mutation < 88) {                                                       
//                int secondCreature = RangedRandomNumber(0, NEXT_GENERATION_POPULATION - 1);
//                ExchangeDnaFragments(nextGeneration[creature], nextGeneration[secondCreature]);
//            } else if (mutation < 100) { 
//                RandomFragmentReverse(nextGeneration[creature]);
            }                                                                                   
        }


    for (int i = 0; i < START_POPULATION; i++) {
        if (firstGeneration[i]->genes) {
            free(firstGeneration[i]->genes);
        }
        free(firstGeneration[i]);
    }
    free(firstGeneration);
    for (int i = 0; i < NEXT_GENERATION_POPULATION; i++) {
        if (nextGeneration[i]->genes) {
            free(nextGeneration[i]->genes);
        }
        free(nextGeneration[i]);
    }
    free(nextGeneration);

    return 0;
}