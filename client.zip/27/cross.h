#ifndef CROSS_H
#define CROSS_H

using namespace std;

void crossGenome_uint16(struct uint16_genome * genome1, struct uint16_genome * genome2, struct uint16_genome * genome3);

#endif